class TimeScaleWarning(UserWarning):
    pass


class PatchedConicsWarning(UserWarning):
    pass
