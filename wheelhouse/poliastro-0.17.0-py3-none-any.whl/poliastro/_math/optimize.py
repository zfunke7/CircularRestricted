from scipy.optimize import brentq

__all__ = ["brentq"]
