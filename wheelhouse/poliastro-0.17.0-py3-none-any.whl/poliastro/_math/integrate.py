from scipy.integrate import quad

__all__ = ["quad"]
